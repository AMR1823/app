import { Tabs } from 'expo-router';
import { Image } from 'react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: 'white',
          borderTopWidth: 0,
          height: 60,
        },
        tabBarActiveTintColor: '#CC0001',
        tabBarInactiveTintColor: '#999999',
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Oggi',
          tabBarIcon: ({ focused }) => (
            <Image
              source={{ uri: 'https://i.postimg.cc/wvHh0MNc/output-onlinepngtools-1.png' }}
              style={{
                width: 24,
                height: 24,
                tintColor: focused ? '#CC0001' : '#999999',
              }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="didattica"
        options={{
          title: 'Didattica',
          tabBarIcon: ({ focused }) => (
            <Image
              source={{ uri: 'https://i.postimg.cc/Vkqv4RWp/output-onlinepngtools1.png' }}
              style={{
                width: 24,
                height: 24,
                tintColor: focused ? '#CC0001' : '#999999',
              }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="registro"
        options={{
          title: 'Registro',
          tabBarIcon: ({ focused }) => (
            <Image
              source={{ uri: 'https://i.postimg.cc/nLTzfh51/output-onlinepngtools-2.png' }}
              style={{
                width: 24,
                height: 24,
                tintColor: focused ? '#CC0001' : '#999999',
              }}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="mytools"
        options={{
          title: 'MyTools',
          tabBarIcon: ({ focused }) => (
            <Image
              source={{ uri: 'https://i.postimg.cc/mD1D3mjP/Picsart-25-02-11-11-05-04-191.png' }}
              style={{
                width: 24,
                height: 24,
                tintColor: focused ? '#CC0001' : '#999999',
              }}
            />
          ),
        }}
      />
    </Tabs>
  );
}