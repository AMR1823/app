import { View, Text, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, FontAwesome5 } from '@expo/vector-icons';
import { useState, useCallback } from 'react';
import { router } from 'expo-router';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  runOnJS,
} from 'react-native-reanimated';
import { addDays, format, parseISO } from 'date-fns';
import { it } from 'date-fns/locale';

const WeekDays = () => {
  const [currentDate, setCurrentDate] = useState(new Date(2024, 1, 17)); // February 17, 2024
  const [selectedDay, setSelectedDay] = useState('17');
  
  const translateX = useSharedValue(0);
  
  const updateWeek = useCallback((direction: 'forward' | 'backward') => {
    setCurrentDate(prev => {
      const newDate = direction === 'forward' 
        ? addDays(prev, 7) 
        : addDays(prev, -7);
      return newDate;
    });
  }, []);

  const gesture = Gesture.Pan()
    .onUpdate((e) => {
      translateX.value = e.translationX;
    })
    .onEnd((e) => {
      if (Math.abs(e.velocityX) > 500) {
        if (e.velocityX > 0) {
          runOnJS(updateWeek)('backward');
        } else {
          runOnJS(updateWeek)('forward');
        }
      }
      translateX.value = withSpring(0);
    });

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  const days = Array.from({ length: 7 }, (_, i) => {
    const date = addDays(currentDate, i - 3); // Center on current date
    return {
      day: format(date, 'EEEEE', { locale: it }).toUpperCase(),
      date: format(date, 'd'),
      fullDate: date,
    };
  });

  const handleDayPress = (date: string) => {
    setSelectedDay(date);
  };

  return (
    <View style={styles.weekContainer}>
      <GestureDetector gesture={gesture}>
        <Animated.View style={[styles.weekRow, animatedStyle]}>
          {days.map((day, index) => (
            <Pressable
              key={index}
              style={[
                styles.dayContainer,
                day.date === selectedDay && styles.selectedDayContainer,
              ]}
              onPress={() => handleDayPress(day.date)}>
              <Text
                style={[
                  styles.dayText,
                  day.date === selectedDay && styles.selectedDayText,
                ]}>
                {day.day}
              </Text>
              <Text
                style={[
                  styles.dateText,
                  day.date === selectedDay && styles.selectedDayText,
                ]}>
                {day.date}
              </Text>
            </Pressable>
          ))}
        </Animated.View>
      </GestureDetector>
    </View>
  );
};

const AbsenceCard = () => (
  <Pressable style={styles.absenceCard}>
    <View style={styles.absenceHeader}>
      <Text style={styles.absenceTitle}>Assenza</Text>
      <View style={styles.warningIcon}>
        <Ionicons name="warning" size={20} color="#CC0001" />
      </View>
    </View>
    <Text style={styles.absenceSubtitle}>da giustificare</Text>
  </Pressable>
);

const HomeworkCard = ({
  subject,
  teacher,
  time,
  description,
}: {
  subject: string;
  teacher: string;
  time: string;
  description: string;
}) => (
  <View style={styles.homeworkCard}>
    <Text style={styles.subjectText}>{subject}</Text>
    <View style={styles.teacherRow}>
      <FontAwesome5 name="user" size={16} color="#666" />
      <Text style={styles.teacherText}>{teacher}</Text>
      <View style={styles.timeContainer}>
        <FontAwesome5 name="clock" size={16} color="#666" />
        <Text style={styles.timeText}>{time}</Text>
      </View>
    </View>
    <Text style={styles.descriptionText}>{description}</Text>
    <Pressable style={styles.readMoreButton}>
      <Text style={styles.readMoreText}>Leggi di più</Text>
    </Pressable>
  </View>
);

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Image
              source={{ uri: 'https://i.postimg.cc/bwbdRw9T/Picsart-25-02-06-17-29-43-697.png' }}
              style={styles.logo}
            />
            <Text style={styles.monthText}>FEBBRAIO</Text>
          </View>
          <View style={styles.headerIcons}>
            <Pressable style={styles.iconButton}>
              <FontAwesome5 name="calendar-alt" size={24} color="white" />
            </Pressable>
            <Pressable style={styles.iconButton}>
              <Text style={styles.amText}>AM...</Text>
            </Pressable>
          </View>
        </View>

        <WeekDays />
        <AbsenceCard />

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Compiti</Text>
          <Pressable>
            <Text style={styles.seeAllText}>Vedi Tutti</Text>
          </Pressable>
        </View>

        <HomeworkCard
          subject="MATEMATICA"
          teacher="MANIA MARIA GLORIA"
          time="11:00 - 12:00"
          description="Es pag. 261 dal n. 28 al n. 32\nEs pag. 261 dal n.40 al n.42"
        />

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Lezioni</Text>
          <Pressable>
            <Text style={styles.seeAllText}>Vedi Tutti</Text>
          </Pressable>
        </View>

        <HomeworkCard
          subject="LABORATORI TECNOLOGICI ED ESERCITAZIONI"
          teacher="MARCHESI MARCO"
          time="1 ora"
          description="Fotovoltaico, andamento e previsioni future"
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#CC0001',
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  headerLeft: {
    alignItems: 'flex-start',
  },
  logo: {
    width: 150,
    height: 40,
    resizeMode: 'contain',
    marginBottom: 8,
  },
  monthText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: -4,
  },
  headerIcons: {
    flexDirection: 'row',
    gap: 15,
  },
  iconButton: {
    padding: 5,
  },
  amText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  weekContainer: {
    backgroundColor: '#CC0001',
    overflow: 'hidden',
  },
  weekRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
  },
  dayContainer: {
    alignItems: 'center',
    padding: 10,
    borderRadius: 25,
    width: 50,
    height: 50,
    justifyContent: 'center',
  },
  selectedDayContainer: {
    backgroundColor: 'white',
  },
  dayText: {
    color: 'white',
    fontSize: 16,
  },
  dateText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedDayText: {
    color: '#CC0001',
  },
  absenceCard: {
    backgroundColor: 'white',
    margin: 15,
    padding: 20,
    borderRadius: 15,
    elevation: 3,
  },
  absenceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  absenceTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#CC0001',
  },
  warningIcon: {
    backgroundColor: '#FFE5E5',
    padding: 8,
    borderRadius: 20,
  },
  absenceSubtitle: {
    color: '#666',
    fontSize: 16,
    marginTop: 5,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
  },
  sectionTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
  },
  seeAllText: {
    color: '#666',
    fontSize: 16,
  },
  homeworkCard: {
    backgroundColor: 'white',
    margin: 15,
    marginTop: 0,
    padding: 20,
    borderRadius: 15,
    elevation: 3,
  },
  subjectText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  teacherRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    gap: 8,
  },
  teacherText: {
    color: '#666',
    fontSize: 16,
    flex: 1,
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  timeText: {
    color: '#666',
    fontSize: 16,
  },
  descriptionText: {
    color: '#333',
    fontSize: 16,
    marginTop: 15,
    lineHeight: 24,
  },
  readMoreButton: {
    marginTop: 15,
    alignItems: 'center',
  },
  readMoreText: {
    color: '#CC0001',
    fontSize: 16,
    fontWeight: 'bold',
  },
});